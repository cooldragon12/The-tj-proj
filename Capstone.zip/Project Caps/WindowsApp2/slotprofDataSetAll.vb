﻿

Partial Public Class slotprofDataSetAll
End Class
